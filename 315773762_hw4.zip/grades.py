# -*- coding: utf-8 -*-
"""
Created on Sun Dec  6 18:57:35 2020
Student: osnat yunyan
ID: 315773762
Assignment no. 4
Program: grades.py 
@author: osnat
"""

def file_to_dict (file):
    """The function reads data into a dictionary"""
    f=open(file,"r")
    text=f.read().split("\n")
    f.close()
    if text[-1]=="":
        del text[-1]
    dict={}
    for i in range(len(text)): #The loop goes over the lines of text and puts them in a dictionary
        text[i]=text[i].split()
        if len(text[i][0])!= 9 or not text[i][0].isnumeric():
            return None
        id=text[i][0]
        dict[id]=[]
        for j in range(1,len(text[i])):
            dict[id].append(text[i][j])
    return dict
          
def average_grade_dict(dict):
    """Returns a dictionary whose values ​​are the average of the dictionary entries entered"""
    avg_dict = {}
    for key, value in dict.items(): #Go through the key and the value in the dictionary
        avg = 0
        for i in value: #Enter to avg the value numbers
            avg += float(i)
        avg_dict[key] = float(round(avg / len(value), 2))

    return avg_dict


def value_to_str(dict):
    """Returns a dictionary in which all values are of type string"""
    str_value = ""
    for key, value in dict.items(): #Go through the key and the value in the dictionary
        for i in value:
            str_value += i + " "
        dict[key] = str_value
        str_value = ""
    return dict


def two_to_one_dict(grades, students):
    """Merges two dictionaries into one dictionary and prints its values 
    ​​which are the name and average scores.
    When students appear sorted by the average grade of each student from the highest to the lowest."""
    avg_grades = average_grade_dict(grades)
    students = value_to_str(students)
    sort_grades = dict(sorted(avg_grades.items(), key=lambda item: item[1], reverse=True))
    dict_finel = {}
    for k, v in sort_grades.items(): #Goes through the sorted dictionary
        if k in sort_grades and k in students:
            dict_finel[k] = [students[k], v]
    for k, v in dict_finel.items():
        print(v[0], v[1])
   

def most_times(grades_dict):
    """The function will print the grades that accepted the most times"""
    counter = {}
    for grades_values in grades_dict.values(): #Goes over the dictionary value
        for v in grades_values: #Adds keys and values s to the counter dictionary
            if v in counter.keys():
                counter[v] += 1
            else:
                counter[v] = 1
    most_time_lst = []
    for key, val in counter.items(): #Checks for which key the high values ​​and adds them to the list
        if str(val) in str(max(counter.values())):
              most_time_lst.append(int(key))
    print("Most common grades:", most_time_lst)


def grade_to_list(grades):
    """Convert values in a dictionary into list of values. """
    lstgrade = []
    for i in grades: #Going through the dictionary keys
        lstgrade.append(grades[i])
    return lstgrade


def get_common_elements(lst_of_lst):
    """The function returns a list of grades received from more than one student"""
    union_set = set()
    for lst in range(len(lst_of_lst) - 1):
        set_grade = set(lst_of_lst[lst])
        for j in range(lst + 1, len(lst_of_lst)):
            set_2 = set(lst_of_lst[j])
            union_set |= (set_grade & set_2)
    lst_finel = [(i) for i in union_set]
    return "Grades that received from more than one student:\n%s" % (','.join(lst_finel))


def check_legal_dict(grade_dict, name_dict):
    """Return None if one of the dictionaries is not legal."""
    for k, v in grade_dict.items():
        if k not in name_dict or len(v) == 0: #Goes through the keys and values dictionary
            return None
    for k, v in name_dict.items(): ##Goes through the keys and values dictionary
        if k not in grade_dict or len(v) == 0:
            return None
    return grade_dict, name_dict


def main():
    grades_dict = file_to_dict("grades.txt")
    names_dict = file_to_dict("students.txt")
    if grades_dict is None or names_dict is None:
        print("Error")
        return None
    if check_legal_dict(grades_dict, names_dict) is None:
        print("Error")
        return None
    two_to_one_dict(grades_dict, names_dict)
    check_legal_dict(grades_dict, names_dict)
    most_times(grades_dict)
    print(get_common_elements(grade_to_list(grades_dict)))
    
main()